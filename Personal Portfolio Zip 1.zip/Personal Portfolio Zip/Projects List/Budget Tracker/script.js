const budgetForm = document.getElementById('budget-form');
const incomeInput = document.getElementById('income-input');
const expenseForm = document.getElementById('expense-form');
const expenseInput = document.getElementById('expense-input');
const amountInput = document.getElementById('amount-input');
const incomeAmount = document.getElementById('income-amount');
const expenseAmount = document.getElementById('expense-amount');
const remainingAmount = document.getElementById('remaining-amount');

let income = 0;
let expenses = 0;

budgetForm.addEventListener('submit', function(event) {
  event.preventDefault();
  const incomeValue = parseFloat(incomeInput.value);
  if (!isNaN(incomeValue)) {
    income += incomeValue;
    incomeAmount.textContent = `$${income.toFixed(2)}`;
    remainingAmount.textContent = `$${(income - expenses).toFixed(2)}`;
    incomeInput.value = '';
  }
});

expenseForm.addEventListener('submit', function(event) {
  event.preventDefault();
  const expenseValue = expenseInput.value;
  const amountValue = parseFloat(amountInput.value);
  if (!isNaN(amountValue)) {
    expenses += amountValue;
    expenseAmount.textContent = `$${expenses.toFixed(2)}`;
    remainingAmount.textContent = `$${(income - expenses).toFixed(2)}`;
    const li = document.createElement('li');
    li.textContent = `${expenseValue}: $${amountValue.toFixed(2)}`;
    document.getElementById('expense-list').appendChild(li);
    expenseInput.value = '';
    amountInput.value = '';
  }
});